<?php
/**
 * Created by PhpStorm.
 * User: Jack<376927050@qq.com>
 * Date: 2018/10/21
 * Time: 9:10
 */
namespace framework\db;


class MySQLPDO
{
    // PDO对象
    public static $pdo;

    public function __construct()
    {
        self::$pdo || self::connect();
    }

    /**
     * 获取pdo对象
     */
    public static function connect()
    {
        list($host,$dbname,$charset,$user,$pwd) = [
            C('db.dbhost'),
            C('db.dbname'),
            C('db.charset'),
            C('db.user'),
            C('db.pwd')
        ];
+
        $dsn = "mysql:host=$host;dbname=$dbname;charset=$charset";
        //建立持久化连接
        self::$pdo = new \PDO($dsn,$user,$pwd,[\PDO::ATTR_PERSISTENT=>true]);
        // 设置错误处理为抛PDO异常
        self::$pdo->setAttribute(\PDO::ATTR_ERRMODE,\PDO::ERRMODE_EXCEPTION);
    }

    public function query($sql,array $data)
    {
        $sth = self::$pdo->prepare($sql);
        $sth->execute($data);
        return $sth;
    }

    /**
     * 获取查询所有结果集
     * @param $sql
     * @param array $data
     * @return array
     */
    public function fetchAll($sql,array $data=[])
    {
        return $this->query($sql,$data)->fetchAll(\PDO :: FETCH_ASSOC );
    }

    /**
     * 执行SQL-写操作（支持批量操作，返回受影响的行数）
     * @param $sql
     * @param array $data
     * @return integer
     */
    public function exec($sql, $data=[])
    {
        return $this->query($sql, $data)->rowCount();
    }

    /**
     * 取得一行结果
     * @param $sql
     * @param array $data
     * @return array
     */
    public function fetchRow($sql, $data=[])
    {
        return $this->query($sql, $data)->fetch(\PDO::FETCH_ASSOC);
    }

    /**
     * 取得一列结果
     * @param $sql
     * @param array $data
     * @return mixed
     */
    public function fetchColumn($sql, $data=[])
    {
        return $this->query($sql, $data)->fetchColumn();
    }

    /**
     * 最后插入的ID
     * @return mixed
     */
    public function lastInsertId()
    {
        return self::$pdo->lastInsertId();
    }

    /**
     * 事务处理-启动
     * @return mixed
     */
    public function startTrans()
    {
        return self::$pdo->beginTransaction();
    }

    /**
     * 事务处理-提交
     * @return mixed
     */
    public function commit()
    {
        return self::$db->commit();
    }

    /**
     * 事务处理-回滚
     * @return mixed
     */
    public function rollBack()
    {
        return self::$pdo->rollBack();
    }
}