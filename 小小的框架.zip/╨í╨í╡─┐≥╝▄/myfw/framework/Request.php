<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2019/2/26 0026
 * Time: 下午 9:07
 */
namespace framework;

class Request
{
    public $controller;
    public $action;
    private static $instance;

    private function __construct()
    {
        $this->controller = isset($_GET['c']) && !empty($_GET['c']) ? ucfirst(strtolower($_GET['c'])) : 'Home';
        $this->action = isset($_GET['a']) && !empty($_GET['a']) ? strtolower($_GET['a']) : 'index';
    }

    public static function getInstance()
    {
        if(self::$instance == null){
            self::$instance = new self;
        }
        return self::$instance;
    }

    public function __clone()
    {
        // TODO: Implement __clone() method.
    }
}