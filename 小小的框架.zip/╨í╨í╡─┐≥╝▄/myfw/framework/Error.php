<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2019/2/26 0026
 * Time: 下午 2:58
 */
namespace framework;
class Error
{
    public static function start()
    {
        set_error_handler([__CLASS__,'appException']);              //普通错误处理
        register_shutdown_function([__CLASS__,'addException']);     //致命错误处理
        set_exception_handler([__CLASS__,'app']);                   //异常处理
    }

    public static function appException($errno,$errstr,$errfile,$errline)
    {
        header('HTTP/1.1 200 OK');
        $file = "错误级别：" . $errno . '---' . "错误信息：" . $errstr . '---' . "错误文件：" . $errfile . '---' . "错误行数：" . $errline;
    }

    public static function addException()
    {
        $er = error_get_last();
        if( ($error = $er) != null ){
            self :: appException($er['type'],$er['message'],$er['file'],$er['line']);
        }
    }
    public static function app(\Exception $e)
    {
        var_dump($e);
        die;
        $file = "错误级别：" . $errno . '---' . "错误信息：" . $errstr . '---' . "错误文件：" . $errfile . '---' . "错误行数：" . $errline;
        file_put_contents(file_put_contents($location,$data.PHP_EOL,FILE_APPEND));
    }
    private static function fileLogs()
    {

    }
}