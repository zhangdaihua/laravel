<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2019/2/26 0026
 * Time: 下午 9:07
 */

namespace framework;


class Controller
{
    private $view;
    public function __construct()
    {
        $this->view = new View();
    }

    public function __call($name, $arguments)
    {
        if( is_callable([$this->view,$name]) ){
            return call_user_func_array([$this->view,$name],$arguments);
        }
    }
}