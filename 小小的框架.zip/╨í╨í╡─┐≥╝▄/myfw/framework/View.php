<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2019/2/27 0027
 * Time: 上午 9:45
 */

namespace framework;


class View
{
    public function render()
    {
        $viewFile = PATH_VIEW . DS . strtolower(Request::getInstance()->controller) . DS . Request::getInstance()->action . '.html';
        require_once $viewFile;
    }

}