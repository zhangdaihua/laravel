<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2019/2/26 0026
 * Time: 下午 2:58
 */
namespace framework;

class Loading
{
    public static function start()
    {
        spl_autoload_register([__CLASS__,'load']);      //自动加载获取数据函数
        Error::start();                                 //调用错误处理方法
        self::initConst();
        self::links();                                  //执行页面加载显示
    }
    protected static function load($className)          //自动加载
    {
        $fileName = str_replace('\\','/',$className . '.php');  //拼接路径
        if( !file_exists($fileName) ){                  //判断准备加载的文件是否存在
            throw new \Exception($fileName.'文件不存在');
        }
        require_once $fileName;         //引入文件
    }

    private static function initConst()
    {
        define('PATH_ROOT',dirname(__DIR__));
        define('DS',DIRECTORY_SEPARATOR);
        define('PATH_APP',PATH_ROOT . DS . 'application');
        define('PATH_VIEW',PATH_APP .DS . 'view' );
        //define('PATH_LOGS','./public/logs');
    }

    protected static function links()
    {
        $controller = 'application\controller\\'.Request::getInstance()->controller;       //拼接需要调用的类
        if(!class_exists($controller)){                 //判断有没有定义这个类
            throw new \Exception('未定义类');
        }
        $objClass = new $controller();                  //new 这个类
        $action = Request::getInstance()->action;
        if( !is_callable([$objClass,$action]) ){        //判断这个方法是否存在或者是否可调用
            throw new \Exception($action.'不可调用方法');
        }
        $objClass->$action();                           //调用这个方法
    }
}