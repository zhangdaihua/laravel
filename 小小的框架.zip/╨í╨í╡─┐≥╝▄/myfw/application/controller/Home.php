<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2019/2/26 0026
 * Time: 下午 2:59
 */
namespace application\controller;

class Home extends \framework\Controller
{
    public function index()
    {
        (new \framework\View())->render();
    }
    public function aboutus()
    {
        (new \framework\View())->render();
    }
}