<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2019/2/26 0026
 * Time: 下午 2:59
 */
namespace application\controller;

class Message extends \framework\Controller
{
    public function add()
    {
        (new \framework\View())->render();
    }

    public function admin()
    {
        (new \framework\View())->render();
    }

    public function update()
    {
        (new \framework\View())->render();
    }

    public function index()
    {
        (new \framework\View())->render();
    }
}