<?php
/**
 * 主文件
 * User: Administrator
 * Date: 2019/2/26 0026
 * Time: 下午 2:58
 */
header('content-type:text/html;charset=utf-8');
require_once 'framework\Loading.php';   //引入自动加载文件
\framework\Loading::start();            //调用自动加载方法
